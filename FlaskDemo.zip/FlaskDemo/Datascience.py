import matplotlib.pyplot as plt

x = [1,2,3,4,5]
y = [100,200,300,400,500]
plt.plot(x,y)

#plt.show()

#df = pd.read_csv("/home/abhilash/Documents/files/CSV_files/cars.csv")
#print(df.groupby('make').count())
# print(type(df.groupby('make')))
# print(df.head())
