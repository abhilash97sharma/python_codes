from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)


@app.route('/hi')
def fun3():
    s1 = request.form['opt1']
    return s1
    # return redirect(url_for(request.form['opt1']))


@app.route('/home')
def fun2():
    return render_template('index3.html')


@app.route('/hello/<user>')
def fun1(user):
    f1 = fun2()
    return render_template('index.html', name=user + ' ' + f1)


@app.route('/page45')
def fun12():
    return render_template('index2.html')


@app.route('/userinput', methods=['POST'])
def fun21():
    i1 = int(request.form['txt1'])
    i2 = int(request.form['txt2'])
    i3 = i1 + i2
    return '<h2>Sum of num: ' + str(i3) + '</h2>'
    # return 'hello abhilash'


if __name__ == '__main__':
    app.run(host='0.0.0.0')
